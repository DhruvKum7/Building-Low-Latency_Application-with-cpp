#include "common/logging.h"

namespace Common {
}